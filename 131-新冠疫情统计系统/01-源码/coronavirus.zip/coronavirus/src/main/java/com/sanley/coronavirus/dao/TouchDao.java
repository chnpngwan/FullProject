package com.sanley.coronavirus.dao;

import com.sanley.coronavirus.entity.Base;
import com.sanley.coronavirus.entity.Touch;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface TouchDao {
    @Select("select baseId,comeFrom,isoAddress,startDate,finished from touch where finished ='否' ")
    @Results({
            @Result(id = true, property = "baseId", column = "baseId"),
            @Result(property = "comeFrom", column = "comeFrom"),
            @Result(property = "isoAddress", column = "isoAddress"),
            @Result(property = "startDate", column = "startDate"),
            @Result(property = "finished", column = "finished"),
            @Result(property = "base",column = "baseId",javaType = Base.class,one = @One(select = "com.sanley.coronavirus.dao.BaseDao.findById"))
    })
    //查看所有接触案例
    public List<Touch> findAll();
    //添加接触信息
    @Insert("insert into touch(baseId,comeFrom,isoAddress,startDate,finished)values(#{baseId},#{comeFrom},#{isoAddress},#{startDate},#{finished})")
    public void add(Touch touch);

    @Select("select baseId,comeFrom,isoAddress,startDate,finished from touch where baseId =#{baseId} ")
    @Results({
            @Result(id = true, property = "baseId", column = "baseId"),
            @Result(property = "comeFrom", column = "comeFrom"),
            @Result(property = "isoAddress", column = "isoAddress"),
            @Result(property = "startDate", column = "startDate"),
            @Result(property = "finished", column = "finished"),
            @Result(property = "base",column = "baseId",javaType = Base.class,one = @One(select = "com.sanley.coronavirus.dao.BaseDao.findById"))
    })
    //通过id查找密切接触者
    public Touch findById(int baseId);

    @Select("SELECT baseId,comeFrom,isoAddress,startDate,finished " +
            " FROM touch WHERE baseId in(select id from base where name like #{name})")
    @Results({
            @Result(id = true, property = "baseId", column = "baseId"),
            @Result(property = "comeFrom", column = "comeFrom"),
            @Result(property = "isoAddress", column = "isoAddress"),
            @Result(property = "startDate", column = "startDate"),
            @Result(property = "finished", column = "finished"),
            @Result(property = "base", column = "baseId", javaType = Base.class, one = @One(select = "com.sanley.coronavirus.dao.BaseDao.findById"))
    })
    //根据姓名查找病人
    public List<Touch> findByName(String name);

    //将此接触者隔离状态完成
    @Update("update touch set finished='是' where baseId=#{baseId}")
    public void toSafe(int baseId);
    //现存隔离人数
    @Select("select sum(1) from touch where finished ='否' ")
    public Integer currentNumber();
    //累计隔离人数
    @Select("select sum(1) from touch  ")
    public Integer number();
}
