package com.wangjiangfei.entity;

import lombok.Data;

@Data
public class Unit {

  private Integer unitId;
  private String unitName;

}
