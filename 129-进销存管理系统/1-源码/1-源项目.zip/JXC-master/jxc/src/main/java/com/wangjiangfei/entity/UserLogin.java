package com.wangjiangfei.entity;

import lombok.Data;

@Data
public class UserLogin {

    private String userName;
    private String password;
    private String imageCode;
}
