一个利用[百度定位API](http://developer.baidu.com/map/) 以及百度天气API制作的简单天气预报页面。
可以显示当前城市四天内的天气情况。

![](http://ww3.sinaimg.cn/mw690/62d95157gw1ezasi5ix1gj211y0hvaha.jpg)

[点击查看效果](http://zhangjh.me/local-weather/index.html)


[![GPL Licence](https://badges.frapsoft.com/os/gpl/gpl.svg?v=103)](https://opensource.org/licenses/GPL-3.0/)  [![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badge/)  [![Edit By zhangjh](https://img.shields.io/badge/EditBy-Zhangjh-brightgreen.svg?maxAge=2592000)](https://github.com/zhangjh/hello-blog)
