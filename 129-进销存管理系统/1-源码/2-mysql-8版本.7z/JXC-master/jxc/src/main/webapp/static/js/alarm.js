/**
 * 格式价格
 */
function setPriceFormatter(value,row){
	return "￥"+value;
}
