# StuInfoSystem

#### 介绍
学生成绩信息管理系统

#### 使用说明

1.  修改application.yml中的数据库账户密码
2.  点击启动即可


