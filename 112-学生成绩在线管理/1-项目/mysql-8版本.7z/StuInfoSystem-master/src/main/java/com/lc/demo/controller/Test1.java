/*
 * Copyright 2022 tuhu.cn All right reserved. This software is the
 * confidential and proprietary information of tuhu.cn ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Tuhu.cn
 */
package com.lc.demo.controller;

/**
 * @author linchu2
 * @date 2022/1/1216:49
 */
public class Test1 {
    public static void main(String[] args) {

        System.out.println("test111test");

        System.out.println("test11mast");

    }
}
