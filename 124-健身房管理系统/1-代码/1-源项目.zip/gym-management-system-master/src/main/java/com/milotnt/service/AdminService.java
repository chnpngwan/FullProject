package com.milotnt.service;

import com.milotnt.pojo.Admin;

/**
 * @author ZhangMing [1157038410@qq.com]
 * @date 2021/8/11
 */

public interface AdminService {

    //管理员登录
    Admin adminLogin(Admin admin);

}
