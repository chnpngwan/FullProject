package com.jiajiao.test;

import com.jiajiao.utils.ArrayHelper;


public class Main {

	public static void main(String[] args) {
	
		String c = "";
		
		
		System.out.println(c.length());
		
	}
	

}
