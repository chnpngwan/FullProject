package com.jiajiao.bean;

public class Area {
	private int aId;
	private String province;
	private String city;
	private String district;
	private String town;
	public int getAId() {
		return aId;
	}
	public void setAId(int id) {
		aId = id;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	
	
}
