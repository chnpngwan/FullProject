package com.jiajiao.service;

import java.util.List;

import com.jiajiao.bean.GradePrice;

public interface GradePriceService {
	public List<GradePrice> findAllCoursePriceList();
}
