package com.jiajiao.service;

import java.util.List;

import com.jiajiao.bean.District;

public interface DistrictService {

	public List<District> findAllDistrictList();
}
