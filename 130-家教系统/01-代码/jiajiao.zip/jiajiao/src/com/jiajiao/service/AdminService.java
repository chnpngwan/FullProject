package com.jiajiao.service;

import com.jiajiao.bean.Admin;

public interface AdminService {

	public Admin login(Admin admin);
}
