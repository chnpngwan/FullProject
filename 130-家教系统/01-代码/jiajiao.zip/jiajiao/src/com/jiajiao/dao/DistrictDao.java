package com.jiajiao.dao;

import java.util.List;

import com.jiajiao.bean.District;

public interface DistrictDao {

	public List<District> findAllDistrictList();
}
