package com.jiajiao.dao;

import java.util.List;

import com.jiajiao.bean.GradePrice;


public interface GradePriceDao {

	public List<GradePrice> findAllCoursePriceList();

}
