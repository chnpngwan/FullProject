package com.jiajiao.dao;

import com.jiajiao.bean.Area;

public interface AreaDao {

	public Area findById(int id);
	
}
