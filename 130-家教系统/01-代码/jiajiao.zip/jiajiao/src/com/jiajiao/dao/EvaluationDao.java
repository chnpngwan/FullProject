package com.jiajiao.dao;

public interface EvaluationDao {

}
