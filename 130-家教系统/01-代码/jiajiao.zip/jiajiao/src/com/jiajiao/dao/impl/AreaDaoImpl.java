package com.jiajiao.dao.impl;

import com.jiajiao.bean.Area;
import com.jiajiao.dao.AreaDao;

public class AreaDaoImpl implements AreaDao {

	public Area findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
