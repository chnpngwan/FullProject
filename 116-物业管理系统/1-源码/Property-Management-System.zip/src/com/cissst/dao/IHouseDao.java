package com.cissst.dao;

import java.util.List;

import com.cissst.entity.House;

public interface IHouseDao {
	List<House> getAllHouse();
	void add(House h);
	void update(House h);
	void delete(String id);
	List<House> getHouseByOwnerid(String oid);
	House findById(String id);
}
