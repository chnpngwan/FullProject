package com.xtu.hrms.mapper;

import com.xtu.hrms.bean.Position;

import java.util.List;

public interface PositionMapper {
    List<Position> getAllPositions();
}
