package com.xtu.hrms.service;

import com.xtu.hrms.bean.Position;

import java.util.List;

public interface IPositionService {
    List<Position> getAllPositions();
}
