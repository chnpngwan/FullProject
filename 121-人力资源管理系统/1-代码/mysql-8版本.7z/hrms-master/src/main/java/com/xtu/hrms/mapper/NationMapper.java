package com.xtu.hrms.mapper;

import com.xtu.hrms.bean.Nation;

import java.util.List;

public interface NationMapper {
    List<Nation> getAllNations();
}
