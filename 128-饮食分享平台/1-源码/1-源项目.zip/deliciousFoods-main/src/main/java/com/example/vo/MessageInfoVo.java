package com.example.vo;

import com.example.entity.MessageInfo;

public class MessageInfoVo extends MessageInfo {



}