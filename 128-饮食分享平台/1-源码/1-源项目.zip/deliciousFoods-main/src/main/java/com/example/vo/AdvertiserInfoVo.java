package com.example.vo;

import com.example.entity.AdvertiserInfo;

public class AdvertiserInfoVo extends AdvertiserInfo {



}