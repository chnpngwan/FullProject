package com.example.vo;

import com.example.entity.CollectInfo;

public class CollectInfoVo extends CollectInfo {

	private String foodsName;

	public String getFoodsName() {
		return foodsName;
	}
	public void setFoodsName(String foodsName) {
		this.foodsName = foodsName;
	}

}