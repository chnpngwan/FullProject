package com.example.vo;

import com.example.entity.NotesInfo;

public class NotesInfoVo extends NotesInfo {

	private String userName;

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}