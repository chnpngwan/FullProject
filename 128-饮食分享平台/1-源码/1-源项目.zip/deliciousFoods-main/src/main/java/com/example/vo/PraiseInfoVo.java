package com.example.vo;

import com.example.entity.PraiseInfo;

public class PraiseInfoVo extends PraiseInfo {

	private String notesName;

	public String getNotesName() {
		return notesName;
	}
	public void setNotesName(String notesName) {
		this.notesName = notesName;
	}

}