package com.example.vo;

import com.example.entity.AdminInfo;

public class AdminInfoVo extends AdminInfo {



}