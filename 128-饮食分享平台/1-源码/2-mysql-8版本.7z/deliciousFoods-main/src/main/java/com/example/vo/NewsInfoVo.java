package com.example.vo;

import com.example.entity.NewsInfo;

public class NewsInfoVo extends NewsInfo {



}