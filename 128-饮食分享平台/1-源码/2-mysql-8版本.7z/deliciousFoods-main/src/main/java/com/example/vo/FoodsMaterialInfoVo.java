package com.example.vo;

import com.example.entity.FoodsMaterialInfo;

public class FoodsMaterialInfoVo extends FoodsMaterialInfo {



}