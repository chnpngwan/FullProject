package com.example.vo;

import com.example.entity.SubClassifyInfo;

public class SubClassifyInfoVo extends SubClassifyInfo {

	private String classifyName;

	public String getClassifyName() {
		return classifyName;
	}
	public void setClassifyName(String classifyName) {
		this.classifyName = classifyName;
	}

}