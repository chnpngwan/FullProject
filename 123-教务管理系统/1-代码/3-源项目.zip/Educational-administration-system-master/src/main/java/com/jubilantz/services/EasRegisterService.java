package com.jubilantz.services;

/**
 * @Author JubilantZ
 * @Date: 2021/4/24 17:08
 */
public interface EasRegisterService {
}
