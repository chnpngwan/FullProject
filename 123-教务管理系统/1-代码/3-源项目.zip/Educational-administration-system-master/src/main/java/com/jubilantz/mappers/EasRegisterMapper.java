package com.jubilantz.mappers;

import org.apache.ibatis.annotations.Mapper;

/**
 * @Author JubilantZ
 * @Date: 2021/4/24 17:08
 */
@Mapper
public interface EasRegisterMapper {
}
