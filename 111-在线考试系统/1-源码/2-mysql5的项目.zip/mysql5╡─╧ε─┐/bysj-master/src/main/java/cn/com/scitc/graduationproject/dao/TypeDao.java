package cn.com.scitc.graduationproject.dao;

import cn.com.scitc.graduationproject.model.Type;
import org.springframework.data.repository.CrudRepository;

public interface TypeDao extends CrudRepository<Type,Integer> {
}
