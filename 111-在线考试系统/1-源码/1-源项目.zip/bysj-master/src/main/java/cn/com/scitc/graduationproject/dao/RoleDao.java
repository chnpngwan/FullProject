package cn.com.scitc.graduationproject.dao;

import cn.com.scitc.graduationproject.model.Role;
import org.springframework.data.repository.CrudRepository;

public interface RoleDao extends CrudRepository<Role,Integer> {
}
