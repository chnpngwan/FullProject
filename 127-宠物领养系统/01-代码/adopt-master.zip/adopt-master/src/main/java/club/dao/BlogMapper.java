package club.dao;

import club.pojo.Blog;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface BlogMapper extends BaseMapper<Blog> {

}
