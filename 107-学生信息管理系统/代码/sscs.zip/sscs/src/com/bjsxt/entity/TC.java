package com.bjsxt.entity;

import java.util.Date;

public class TC {
	   private int cno;
		
		private String name;
		
		private int credit;
		
		private Date periodstart;
		
		private Date periodend;
		
		
		private int  tno;
		
		private String tname;
		
		private String pwd;
		
		private String phone;
		
		private Date hiredate;
		
		private String remark;
		
		
		
	
	
}
