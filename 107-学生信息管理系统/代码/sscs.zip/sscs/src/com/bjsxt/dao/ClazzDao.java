package com.bjsxt.dao;

import java.util.List;

import com.bjsxt.entity.Clazz;

public interface ClazzDao {
	
	//��ѯ���еİ༶����Ϣ
	public    List<Clazz>  selectAll();

}
