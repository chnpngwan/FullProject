package com.bjsxt.test;

public class Test1 {
	
	public static void main(String[] args) {
		
		   Fu  a=new  A();
		   
		   a.service();
		   
		   Fu  b =new  B();
		   
		   b.service();
		
		
	}
	
	public  void  a(){
		
		System.out.println("Test1.a()");
		
		
	}

	public   void   c(){
		
		System.out.println("Test1.c()");
		
		System.out.println("hhh");
	}
	
	public  void  d(){
		
		System.out.println("Test1.d()");
	}

	
	public  void  b(){
		
		System.out.println("Test1.b()");
		
		
	}
	


}
