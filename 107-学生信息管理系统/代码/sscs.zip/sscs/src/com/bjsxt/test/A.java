package com.bjsxt.test;

public class A extends Fu{

}
