package com.bjsxt.test;

public class B extends  Fu{

}
