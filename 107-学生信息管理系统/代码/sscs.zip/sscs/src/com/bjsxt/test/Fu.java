package com.bjsxt.test;

public class Fu {
	
	public   void  service(){
		
		
		System.out.println(this.getClass());
	}

}

