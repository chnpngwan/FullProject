/**
 * 实体包，此java package中存放的均为实体类，对应数据库表映射
 *
 * @author zyp
 * @version 0.0.1
 * @since 0.0.1
 */
package sut.edu.zyp.dormitory.manage.entity;